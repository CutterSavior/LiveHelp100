﻿/**
 * 系统配置项常量
 */
export const CONFIG_KEYS = {
  FILE_SERVER_BASE_URL: 'FILE_SERVER_BASE_URL'
} as const
