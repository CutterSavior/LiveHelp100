import DictSelect from './DictSelect.vue'

export default DictSelect
