import DictRadioGroup from './DictRadioGroup.vue'

export default DictRadioGroup
