import TabsView from './TabsView.vue'

export default TabsView
export { TabsView }
