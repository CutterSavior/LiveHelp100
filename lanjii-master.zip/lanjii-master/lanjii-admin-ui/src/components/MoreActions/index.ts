﻿import MoreActions from './MoreActions.vue'

export default MoreActions
