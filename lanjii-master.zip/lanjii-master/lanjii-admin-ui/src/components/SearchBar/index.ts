import SearchBar from './SearchBar.vue'

export default SearchBar
export { SearchBar }
