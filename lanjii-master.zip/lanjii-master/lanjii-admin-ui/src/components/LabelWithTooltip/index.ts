export { default as LabelWithTooltip } from './LabelWithTooltip.vue';
