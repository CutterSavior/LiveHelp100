import DictTag from './DictTag.vue'

export default DictTag
