﻿<template>
  <LeftBar/>
  <RightBar/>
</template>

<script lang="ts" setup>
import RightBar from "@/layouts/components/BaseHeader/components/RightBar.vue";
import LeftBar from "@/layouts/components/BaseHeader/components/LeftBar.vue";
</script>