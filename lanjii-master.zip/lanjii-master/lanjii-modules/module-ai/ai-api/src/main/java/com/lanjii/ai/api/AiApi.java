package com.lanjii.ai.api;

/**
 * AI模块对外API接口
 *
 * @author lanjii
 */
public interface AiApi {
}
