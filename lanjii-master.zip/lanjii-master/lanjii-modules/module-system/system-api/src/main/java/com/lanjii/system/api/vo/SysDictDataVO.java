package com.lanjii.system.api.vo;

import com.lanjii.common.base.BaseVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 字典数据表(SysDictData) VO
 *
 * @author lanjii
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SysDictDataVO extends BaseVO {

    /**
     * 字典数据主键
     */
    private Long id;

    /**
     * 字典排序
     */
    private Integer sortOrder;

    /**
     * 字典标签
     */
    private String dictLabel;

    /**
     * 字典键值
     */
    private Integer dictValue;

    /**
     * 字典类型编码
     */
    private String dictType;


    /**
     * 是否启用（1启用 0禁用）
     */
    private Integer isEnabled;

    /**
     * 备注
     */
    private String remark;

    /**
     * 标签类型
     */
    private String tagType;

    /**
     * 标签颜色
     */
    private String tagColor;

    /**
     * 标签主题
     */
    private String tagEffect;

}
