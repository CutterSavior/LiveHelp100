package com.lanjii.common.enums;

/**
 * 排序
 *
 * @author lanjii
 */
public enum SortOrder {
    ASC, DESC
}